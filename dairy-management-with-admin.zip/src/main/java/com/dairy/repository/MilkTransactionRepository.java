package com.dairy.repository;

import com.dairy.model.MilkTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MilkTransactionRepository extends JpaRepository<MilkTransaction, Long> {
}
