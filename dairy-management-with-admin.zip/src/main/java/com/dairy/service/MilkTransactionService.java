package com.dairy.service;

import com.dairy.model.MilkTransaction;
import com.dairy.repository.MilkTransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MilkTransactionService {
    @Autowired
    private MilkTransactionRepository repo;

    public MilkTransaction saveTransaction(MilkTransaction t) {
        t.setInvoiceNumber("INV-" + System.currentTimeMillis());
        return repo.save(t);
    }

    public List<MilkTransaction> getAllTransactions() {
        return repo.findAll();
    }
}
