-- Database for Dairy Management
CREATE DATABASE IF NOT EXISTS dairy_db;
USE dairy_db;
-- Tables are same as explained in previous answer
