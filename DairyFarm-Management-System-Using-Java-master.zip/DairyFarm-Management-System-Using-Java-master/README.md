
Dairy Farm Management System Using Java-Netbeans
================================================================================

This is a full Dairy management system that records farmer's details and collects data of the milk sold everyday 
Computes them and gives details / monthly reports , The system has three roles admin,Staff and Sellers

An admin is the controller of the system , and the staff can add customers/sellers and enter their daily milk details ,
A seller can log in to view their account and can see the monthly reports of their account 

Used external JAR files including itextpdf,mysql-connector and used Javax, GUI libraries
