 • This application is developed in JAVA.
 • This project provide multiple functionality for dairy ownwers. 
 • For validation purpose we use reactive forms.
 • For Front end designing we use swing and event handling
 • To store the data entered by the user we use MySQL database.
